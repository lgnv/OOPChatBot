package org.telegram.telegrambots.meta.generics;

/**
 * @author Ruben Bermudez
 * @version 1.0
 * Updates reader interface
 */
public interface UpdatesReader {
    void start();
}
