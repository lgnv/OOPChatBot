package org.telegram.telegrambots.meta.generics;

/**
 * @author Ruben Bermudez
 * @version 1.0
 * Base Updates Handler interface
 */
public interface UpdatesHandler {
}
